require "nvchad.autocmds"

-- Öffne NvimTree nur wenn mit '.' oder einem Verzeichnis im aktuellen Pfad gestartet
vim.api.nvim_create_autocmd("VimEnter", {
  callback = function()
    local arg = vim.fn.argv(0)
    
    -- Nur wenn genau ein Argument und es ist ein Verzeichnis
    if vim.fn.argc() == 1 and vim.fn.isdirectory(arg) == 1 then
      -- Wechsle ins Verzeichnis NUR wenn es mit . gestartet wurde
      if arg == "." then
        require("nvim-tree.api").tree.open()
      else
        -- Bei absoluten/relativen Pfaden: wechsle UND öffne Tree
        vim.cmd.cd(arg)
        require("nvim-tree.api").tree.open()
      end
    end
  end,
})
