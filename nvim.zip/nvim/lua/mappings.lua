require "nvchad.mappings"

-- add yours here

local map = vim.keymap.set

map("n", ";", ":", { desc = "CMD enter command mode" })
map("i", "jk", "<ESC>")

-- Diagnostic Navigation
map("n", "[d", vim.diagnostic.goto_prev, { desc = "Vorheriger Diagnostic" })
map("n", "]d", vim.diagnostic.goto_next, { desc = "Nächster Diagnostic" })
map("n", "<leader>e", vim.diagnostic.open_float, { desc = "Zeige Diagnostic Details" })
map("n", "<leader>q", vim.diagnostic.setloclist, { desc = "Diagnostic Liste" })

-- LSP Keybindings
map("n", "gD", vim.lsp.buf.declaration, { desc = "Go to Declaration" })
map("n", "gd", vim.lsp.buf.definition, { desc = "Go to Definition" })
map("n", "K", vim.lsp.buf.hover, { desc = "Hover Documentation" })
map("n", "gi", vim.lsp.buf.implementation, { desc = "Go to Implementation" })
map("n", "<leader>D", vim.lsp.buf.type_definition, { desc = "Type Definition" })
map("n", "<leader>rn", vim.lsp.buf.rename, { desc = "Rename Symbol" })
map("n", "<leader>ca", vim.lsp.buf.code_action, { desc = "Code Actions" })
map("n", "gr", vim.lsp.buf.references, { desc = "Find References" })
map("n", "<leader>f", vim.lsp.buf.format, { desc = "Format Code" })

-- Debug Keybindings
map("n", "<leader>db", "<cmd>DapToggleBreakpoint<CR>", { desc = "Toggle Breakpoint" })
map("n", "<leader>dc", "<cmd>DapContinue<CR>", { desc = "Start/Continue" })
map("n", "<leader>di", "<cmd>DapStepInto<CR>", { desc = "Step Into" })
map("n", "<leader>do", "<cmd>DapStepOver<CR>", { desc = "Step Over" })
map("n", "<leader>dO", "<cmd>DapStepOut<CR>", { desc = "Step Out" })
map("n", "<leader>dt", "<cmd>DapTerminate<CR>", { desc = "Terminate" })

-- Visual Multi Cursor
local opts = { noremap = true, silent = true }
-- Cursor auf nächstes Vorkommen setzen
map("n", "<leader>d", "<Plug>(VM-Find-Under)", vim.tbl_extend("force", opts, { desc = "VM: Mark next occurrence" }))

-- Alle Vorkommen markieren
map("n", "<leader>D", "<Plug>(VM-Select-All)", vim.tbl_extend("force", opts, { desc = "VM: Select all occurrences" }))

-- Subword unter Cursor markieren (Visual Mode)
map("x", "<leader>d", "<Plug>(VM-Find-Subword-Under)", vim.tbl_extend("force", opts, { desc = "VM: Select subword in visual mode" }))

-- Cursor in Nachbarzeilen hinzufügen
map("n", "<leader>j", "<Plug>(VM-Add-Cursor-Down)", vim.tbl_extend("force", opts, { desc = "VM: Add cursor below" }))
map("n", "<leader>k", "<Plug>(VM-Add-Cursor-Up)", vim.tbl_extend("force", opts, { desc = "VM: Add cursor above" }))

-- Cursor überspringen oder entfernen
map("n", "<leader>x", "<Plug>(VM-Skip-Region)", vim.tbl_extend("force", opts, { desc = "VM: Skip current region" }))
map("n", "<leader>p", "<Plug>(VM-Remove-Region)", vim.tbl_extend("force", opts, { desc = "VM: Remove last cursor" }))
-- map({ "n", "i", "v" }, "<C-s>", "<cmd> w <cr>)
