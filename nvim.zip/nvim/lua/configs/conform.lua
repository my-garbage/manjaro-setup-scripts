local options = {
  formatters_by_ft = {
    lua = { "stylua" },
    python = { "black" },
    javascript = { "prettier" },
    typescript = { "prettier" },
    css = { "prettier" },
    html = { "prettier" },
    rust = { "rustfmt" },
    ruby = { "rubocop" },
    java = { "lsp" },
    c = { "clang-format" },
    cpp = { "clang-format" },
    cs = { "csharpier" },
    kotlin = { "ktlint" },
    sh = { "shfmt" },
    php = { "php-cs-fixer" },
    sql = { "sqlfmt" },
    json = { "prettier" },
    jsonc = { "prettier" },
    yaml = { "prettier" },
    markdown = { "prettier" },
  },
  format_on_save = {
    -- These options will be passed to conform.format()
    timeout_ms = 500,
    lsp_fallback = true,
  },
}
return options
