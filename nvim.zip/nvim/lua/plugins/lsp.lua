return {
  {
    "neovim/nvim-lspconfig",
    ft = {
      "python",
      "go",
      "rust",
      "java",
      "kotlin",
      "c",
      "cpp",
      "javascript",
      "javascriptreact",
      "typescript",
      "typescriptreact",
      "ruby",
      "lua",
      "cs",
      "sh",
      "bash",
      "html",
      "css",
      "php",
      "sql",
      "json",
      "yaml",
      "markdown",
      "dockerfile",
      "toml",
    },
    config = function()
      local nvlsp = require "nvchad.configs.lspconfig"

      -- Konfiguration der Diagnosen im LSP
      vim.diagnostic.config {
        virtual_text = true, -- Zeigt Diagnosen direkt im Text an
        signs = true, -- Zeigt die Zeichen in der linken Spalte
        underline = true, -- Unterstreicht die fehlerhaften Stellen
        update_in_insert = true, -- Diagnosen während der Eingabe aktualisieren
      }

      -- LSP-Handler für die Diagnosen
      vim.lsp.handlers["textDocument/publishDiagnostics"] = vim.lsp.with(vim.lsp.diagnostic.on_publish_diagnostics, {
        virtual_text = true, -- Zeigt Diagnosen direkt im Text an
      })

      -- Python
      vim.lsp.config("pyright", {
        cmd = { "pyright-langserver", "--stdio" },
        filetypes = { "python" },
        root_markers = { "pyproject.toml", "setup.py", "requirements.txt", ".git" },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- Go
      vim.lsp.config("gopls", {
        cmd = { "gopls" },
        filetypes = { "go", "gomod", "gowork", "gotmpl" },
        root_markers = { "go.work", "go.mod", ".git" },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
        settings = {
          gopls = {
            completeUnimported = true,
            usePlaceholders = true,
          },
        },
      })

      -- Rust
      vim.lsp.config("rust_analyzer", {
        cmd = { "rust-analyzer" },
        filetypes = { "rust" },
        root_markers = { "Cargo.toml", "rust-project.json" },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
        settings = {
          ["rust-analyzer"] = {
            cargo = { allFeatures = true },
            check = { command = "clippy" },
          },
        },
      })

      -- Java (LSP + DAP)
      vim.lsp.config("jdtls", {
        cmd = { "jdtls" },
        filetypes = { "java" },
        root_markers = {
          ".git",
          "mvnw",
          "gradlew",
          "pom.xml",
          "build.gradle",
          "build.gradle.kts",
        },
        on_attach = function(client, bufnr)
          nvlsp.on_attach(client, bufnr)

          -- 🔌 Java DAP aktivieren
          local jdtls = require "jdtls"

          jdtls.setup_dap { hotcodereplace = "auto" }
          jdtls.setup.add_commands()
        end,
        capabilities = nvlsp.capabilities,

        init_options = {
          bundles = {
            -- Java Debug Adapter
            vim.fn.glob(
              vim.fn.stdpath "data"
                .. "/mason/packages/java-debug-adapter/extension/server/com.microsoft.java.debug.plugin-*.jar",
              true
            ),

            -- Java Test Adapter
            vim.fn.glob(vim.fn.stdpath "data" .. "/mason/packages/java-test/extension/server/*.jar", true),
          },
        },
      })

      -- Kotlin
      vim.lsp.config("kotlin_language_server", {
        cmd = { "kotlin-language-server" },
        filetypes = { "kotlin" },
        root_dir = require("lspconfig.util").root_pattern("settings.gradle", "settings.gradle.kts", ".git"),
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- C/C++
      vim.lsp.config("clangd", {
        cmd = { "clangd" },
        filetypes = { "c", "cpp", "objc", "objcpp", "cuda" },
        root_markers = {
          ".clangd",
          ".clang-tidy",
          ".clang-format",
          "compile_commands.json",
          "compile_flags.txt",
          "configure.ac",
          ".git",
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- JavaScript / TypeScript
      vim.lsp.config("ts_ls", {
        cmd = { "typescript-language-server", "--stdio" },
        filetypes = {
          "javascript",
          "javascriptreact",
          "typescript",
          "typescriptreact",
        },
        root_markers = {
          "package.json",
          "tsconfig.json",
          "jsconfig.json",
          ".git",
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- Ruby
      vim.lsp.config("ruby_lsp", {
        cmd = { "ruby-lsp" },
        filetypes = { "ruby" },
        root_markers = {
          "Gemfile",
          ".ruby-version",
          ".git",
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- C#
      vim.lsp.config("omnisharp", {
        cmd = { "omnisharp" },
        filetypes = { "cs" },
        root_markers = {
          "*.sln",
          "*.csproj",
          ".git",
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,

        settings = {
          FormattingOptions = {
            EnableEditorConfigSupport = true,
            OrganizeImports = true,
          },
          RoslynExtensionsOptions = {
            EnableAnalyzersSupport = true,
            EnableImportCompletion = true,
          },
        },
      })

      -- Lua
      vim.lsp.config("lua_ls", {
        cmd = { "lua-language-server" },
        filetypes = { "lua" },
        root_markers = { ".git", ".luarc.json", "init.lua" },
        settings = {
          Lua = {
            runtime = {
              version = "LuaJIT", -- NVChad nutzt LuaJIT
            },
            diagnostics = {
              globals = { "vim" }, -- Neovim globales vim Objekt
            },
            workspace = {
              library = vim.api.nvim_get_runtime_file("", true),
              checkThirdParty = false,
            },
            telemetry = { enable = false },
          },
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- SH
      vim.lsp.config("bashls", {
        cmd = { "bash-language-server", "start" },
        filetypes = { "sh", "bash" },
      })

      -- HTML
      vim.lsp.config("html", {
        cmd = { "vscode-html-language-server", "--stdio" },
        filetypes = { "html" },
        init_options = {
          configurationSecion = { "html", "css", "javascript" },
          embeddedLanguages = {
            css = true,
            javascript = true,
          },
          provideFormatter = true,
        },
      })

      -- CSS
      vim.lsp.config("cssls", {
        cmd = { "vscode-css-language-server", "--stdio" },
        filetypes = { "css", "scss", "less" },
        settings = {
          css = {
            validate = true,
          },
          scss = {
            validate = true,
          },
          less = {
            validate = true,
          },
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- PHP
      vim.lsp.config("intelephense", {
        cmd = { "intelephense", "--stdio" },
        filetypes = { "php" },
        root_markers = {
          "composer.json",
          ".git",
          "index.php",
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
        settings = {
          intelephense = {
            files = {
              maxSize = 5000000,
            },
          },
        },
      })

      -- SQL
      vim.lsp.config("sqls", {
        cmd = { "sqls" },
        filetypes = { "sql", "mysql" },
        root_markers = { ".git" },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- JSON
      vim.lsp.config("jsonls", {
        cmd = { "vscode-json-language-server", "--stdio" },
        filetypes = { "json", "jsonc" },
        init_options = {
          provideFormatter = true,
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- YAML
      vim.lsp.config("yamlls", {
        cmd = { "yaml-language-server", "--stdio" },
        filetypes = { "yaml", "yaml.docker-compose" },
        settings = {
          yaml = {
            schemas = {
              ["https://json.schemastore.org/github-workflow.json"] = "/.github/workflows/*",
              ["https://raw.githubusercontent.com/compose-spec/compose-spec/master/schema/compose-spec.json"] = "docker-compose*.yml",
            },
          },
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- Markdown
      vim.lsp.config("marksman", {
        cmd = { "marksman", "server" },
        filetypes = { "markdown", "markdown.mdx" },
        root_markers = { ".git", ".marksman.toml" },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- Dockerfile
      vim.lsp.config("dockerls", {
        cmd = { "docker-langserver", "--stdio" },
        filetypes = { "dockerfile" },
        root_markers = { "Dockerfile", ".git" },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- TOML
      vim.lsp.config("taplo", {
        cmd = { "taplo", "lsp", "stdio" },
        filetypes = { "toml" },
        root_markers = { "*.toml", ".git" },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- Auto-enable basierend auf Filetype
      vim.api.nvim_create_autocmd("FileType", {
        pattern = {
          "python",
          "go",
          "rust",
          "java",
          "kotlin",
          "c",
          "cpp",
          "cs",
          "javascript",
          "javascriptreact",
          "typescript",
          "typescriptreact",
          "ruby",
          "lua",
          "sh",
          "bash",
          "html",
          "css",
          "scss",
          "less",
          "php",
          "sql",
          "json",
          "jsonc",
          "yaml",
          "markdown",
          "dockerfile",
          "toml",
        },
        callback = function(args)
          local lsp_map = {
            python = "pyright",
            go = "gopls",
            rust = "rust_analyzer",
            java = "jdtls",
            c = "clangd",
            cpp = "clangd",
            cs = "omnisharp",
            javascript = "ts_ls",
            javascriptreact = "ts_ls",
            typescript = "ts_ls",
            typescriptreact = "ts_ls",
            ruby = "ruby_lsp",
            lua = "lua_ls",
            kotlin = "kotlin_language_server",
            sh = "bashls",
            bash = "bashls",
            html = "html",
            css = "cssls",
            scss = "cssls",
            less = "cssls",
            php = "intelephense",
            sql = "sqls",
            json = "jsonls",
            jsonc = "jsonls",
            yaml = "yamlls",
            markdown = "marksman",
            dockerfile = "dockerls",
            toml = "taplo",
          }

          local lsp_name = lsp_map[args.match]
          if lsp_name then
            vim.schedule(function()
              vim.lsp.enable(lsp_name)
            end)
          end
        end,
      })
    end,
  },

  -- Java Extras
  {
    "mfussenegger/nvim-jdtls",
    ft = "java",
  },
}
