return {
  {
    "neovim/nvim-lspconfig",
    ft = {
      "python",
      "go",
      "rust",
      "java",
      "kotlin",
      "c",
      "cpp",
      "javascript",
      "javascriptreact",
      "typescript",
      "typescriptreact",
      "ruby",
      "lua",
      "cs",
      "sh",
      "html",
    },
    config = function()
      local nvlsp = require "nvchad.configs.lspconfig"

      -- Python
      vim.lsp.config("pyright", {
        cmd = { "pyright-langserver", "--stdio" },
        filetypes = { "python" },
        root_markers = { "pyproject.toml", "setup.py", "requirements.txt", ".git" },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- Go
      vim.lsp.config("gopls", {
        cmd = { "gopls" },
        filetypes = { "go", "gomod", "gowork", "gotmpl" },
        root_markers = { "go.work", "go.mod", ".git" },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
        settings = {
          gopls = {
            completeUnimported = true,
            usePlaceholders = true,
          },
        },
      })

      -- Rust
      vim.lsp.config("rust_analyzer", {
        cmd = { "rust-analyzer" },
        filetypes = { "rust" },
        root_markers = { "Cargo.toml", "rust-project.json" },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
        settings = {
          ["rust-analyzer"] = {
            cargo = { allFeatures = true },
            check = { command = "clippy" },
          },
        },
      })

      -- Java (LSP + DAP)
      vim.lsp.config("jdtls", {
        cmd = { "jdtls" },
        filetypes = { "java" },
        root_markers = {
          ".git",
          "mvnw",
          "gradlew",
          "pom.xml",
          "build.gradle",
          "build.gradle.kts",
        },
        on_attach = function(client, bufnr)
          nvlsp.on_attach(client, bufnr)

          -- 🔌 Java DAP aktivieren
          local jdtls = require "jdtls"

          jdtls.setup_dap { hotcodereplace = "auto" }
          jdtls.setup.add_commands()
        end,
        capabilities = nvlsp.capabilities,

        init_options = {
          bundles = {
            -- Java Debug Adapter
            vim.fn.glob(
              vim.fn.stdpath "data"
              .. "/mason/packages/java-debug-adapter/extension/server/com.microsoft.java.debug.plugin-*.jar",
              true
            ),

            -- Java Test Adapter
            vim.fn.glob(vim.fn.stdpath "data" .. "/mason/packages/java-test/extension/server/*.jar", true),
          },
        },
      })

      -- Kotlin
      vim.lsp.config("kotlin_language_server", {
        cmd = { "kotlin-language-server" },
        filetypes = { "kotlin" },
        root_dir = require("lspconfig.util").root_pattern("settings.gradle", "settings.gradle.kts", ".git"),
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- C/C++
      vim.lsp.config("clangd", {
        cmd = { "clangd" },
        filetypes = { "c", "cpp", "objc", "objcpp", "cuda" },
        root_markers = {
          ".clangd",
          ".clang-tidy",
          ".clang-format",
          "compile_commands.json",
          "compile_flags.txt",
          "configure.ac",
          ".git",
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- JavaScript / TypeScript
      vim.lsp.config("ts_ls", {
        cmd = { "typescript-language-server", "--stdio" },
        filetypes = {
          "javascript",
          "javascriptreact",
          "typescript",
          "typescriptreact",
        },
        root_markers = {
          "package.json",
          "tsconfig.json",
          "jsconfig.json",
          ".git",
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- Ruby
      vim.lsp.config("ruby_lsp", {
        cmd = { "ruby-lsp" },
        filetypes = { "ruby" },
        root_markers = {
          "Gemfile",
          ".ruby-version",
          ".git",
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- C#
      vim.lsp.config("omnisharp", {
        cmd = { "omnisharp" },
        filetypes = { "cs" },
        root_markers = {
          "*.sln",
          "*.csproj",
          ".git",
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,

        settings = {
          FormattingOptions = {
            EnableEditorConfigSupport = true,
            OrganizeImports = true,
          },
          RoslynExtensionsOptions = {
            EnableAnalyzersSupport = true,
            EnableImportCompletion = true,
          },
        },
      })

      -- Lua
      vim.lsp.config("lua_ls", {
        cmd = { "lua-language-server" },
        filetypes = { "lua" },
        root_markers = { ".git", ".luarc.json", "init.lua" },
        settings = {
          Lua = {
            runtime = {
              version = "LuaJIT", -- NVChad nutzt LuaJIT
            },
            diagnostics = {
              globals = { "vim" }, -- Neovim globales vim Objekt
            },
            workspace = {
              library = vim.api.nvim_get_runtime_file("", true),
              checkThirdParty = false,
            },
            telemetry = { enable = false },
          },
        },
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- SH
      local nvlsp = require("nvchad.configs.lspconfig")

      vim.lsp.config("bashls", {
        cmd = { "bash-language-server", "start" },
        filetypes = { "sh", "bash" },
        root_dir = function(fname)
          local util = require("lspconfig.util")
          local root = util.root_pattern(".git", ".bashrc", ".profile")(fname)
          if root then
            return root
          else
            return vim.fn.expand("%:p:h")
          end
        end,
        on_attach = nvlsp.on_attach,
        capabilities = nvlsp.capabilities,
      })

      -- HTML
      vim.lsp.config("html", {
        cmd = { "vscode-html-language-server", "--stdio" },
        filetypes = { "html" },
        root_dir = function(fname)
          local util = require("lspconfig.util")
          local root = util.root_pattern("index.html", "package.json", ".git")(fname)
          if root and vim.fn.isdirectory(root) == 1 then
            return root
          else
            -- fallback: Verzeichnis der geöffneten Datei
            return vim.fn.expand("%:p:h")
          end
        end,
        on_attach = require("nvchad.configs.lspconfig").on_attach,
        capabilities = require("nvchad.configs.lspconfig").capabilities,
      })

      -- Auto-enable basierend auf Filetype
      vim.api.nvim_create_autocmd("FileType", {
        pattern = {
          "python",
          "go",
          "rust",
          "java",
          "kotlin",
          "c",
          "cpp",
          "cs",
          "javascript",
          "javascriptreact",
          "typescript",
          "typescriptreact",
          "ruby",
          "lua",
          "sh",
          "html",
        },
        callback = function(args)
          local lsp_map = {
            python = "pyright",
            go = "gopls",
            rust = "rust_analyzer",
            java = "jdtls",
            c = "clangd",
            cpp = "clangd",
            cs = "omnisharp",
            javascript = "ts_ls",
            javascriptreact = "ts_ls",
            typescript = "ts_ls",
            typescriptreact = "ts_ls",
            ruby = "ruby_lsp",
            lua = "lua_ls",
            kotlin = "kotlin_language_server",
            sh = "bashls",
            html = "html",
          }

          local lsp_name = lsp_map[args.match]
          if lsp_name then
            vim.schedule(function()
              vim.lsp.enable(lsp_name)
            end)
          end
        end,
      })
    end,
  },

  -- Java Extras
  {
    "mfussenegger/nvim-jdtls",
    ft = "java",
  },
}
