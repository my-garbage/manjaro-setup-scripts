return {
  {
    "williamboman/mason.nvim",
    opts = {
      ensure_installed = {
        -- =====================
        -- LSPs
        -- =====================
        "lua-language-server",
        "pyright",
        "gopls",
        "rust-analyzer",
        "jdtls",
        "kotlin-language-server",
        "clangd",
        "typescript-language-server",
        "ruby-lsp",
        "omnisharp",
        "bash-language-server",

        -- =====================
        -- Formatter
        -- =====================
        "stylua",
        "black",
        "prettier",
        "rustfmt",
        "rubocop",
        "clang-format",
        "ktlint",
        "shfmt",
        "csharpier",

        -- =====================
        -- Debugger
        -- =====================
        "codelldb",
        "delve",
        "js-debug-adapter",
        "java-debug-adapter",
        "java-test",
      },
      ui = { check_outdated_packages_on_open = true },
    },
    config = function(_, opts)
      require("mason").setup(opts)
    end,
  },
}
