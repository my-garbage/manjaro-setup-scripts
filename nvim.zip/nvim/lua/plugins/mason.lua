return {
  {
    "williamboman/mason.nvim",
    opts = {
      ensure_installed = {
        -- =====================
        -- LSPs
        -- =====================
        "lua-language-server",
        "pyright",
        "gopls",
        "rust-analyzer",
        "jdtls",
        "kotlin-language-server",
        "clangd",
        "typescript-language-server",
        "ruby-lsp",

        -- =====================
        -- Formatter
        -- =====================
        "stylua",
        "black",
        "prettier",
        "rustfmt",
        "rubocop",
        "clang-format",
        "ktlint",

        -- =====================
        -- Debugger
        -- =====================
        "codelldb",
        "delve",
        "js-debug-adapter",
      },
    },
  },

  {
    "williamboman/mason-lspconfig.nvim",
    opts = {
      automatic_installation = true,
    },
  },
}

