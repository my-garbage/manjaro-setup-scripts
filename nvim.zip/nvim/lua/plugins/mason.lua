return {
  {
    "williamboman/mason.nvim",
    opts = {
      ensure_installed = {
        -- =====================
        -- LSPs
        -- =====================
        "lua-language-server",
        "pyright",
        "gopls",
        "rust-analyzer",
        "jdtls",
        "kotlin-language-server",
        "clangd",
        "typescript-language-server",
        "ruby-lsp",
        "omnisharp",
        "bash-language-server",
        "html-lsp",
        "intelephense",
        "sqls",
        "json-lsp",
        "yaml-language-server",
        "marksman",

        -- =====================
        -- Formatter
        -- =====================
        "stylua",
        "black",
        "prettier",
        "rustfmt",
        "rubocop",
        "clang-format",
        "ktlint",
        "shfmt",
        "csharpier",
        "php-cs-fixer",
        "sqlfmt",

        -- =====================
        -- Debugger
        -- =====================
        "codelldb",
        "delve",
        "js-debug-adapter",
        "java-debug-adapter",
        "java-test",
        "debugpy",
        "php-debug-adapter",
      },
      ui = {
        check_outdated_packages_on_open = true,
        border = "rounded",
      },
    },
    config = function(_, opts)
      require("mason").setup(opts)

      local mr = require "mason-registry"
      local function ensure_installed()
        for _, tool in ipairs(opts.ensure_installed) do
          local p = mr.get_package(tool)
          if not p:is_installed() then
            p:install()
          end
        end
      end

      if mr.refresh then
        mr.refresh(ensure_installed)
      else
        ensure_installed()
      end
    end,
  },
}
