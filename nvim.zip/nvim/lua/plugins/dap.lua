return {
  {
    "mfussenegger/nvim-dap",
    dependencies = {
      "rcarriga/nvim-dap-ui",
      "nvim-neotest/nvim-nio",
      "mfussenegger/nvim-dap-python",
    },

    config = function()
      local dap = require "dap"
      local dapui = require "dapui"

      -- =============================
      -- UI
      -- =============================
      dapui.setup()

      dap.listeners.after.event_initialized["dapui"] = function()
        dapui.open()
      end
      dap.listeners.before.event_terminated["dapui"] = function()
        dapui.close()
      end
      dap.listeners.before.event_exited["dapui"] = function()
        dapui.close()
      end

      -- =============================
      -- Python
      -- =============================
      require("dap-python").setup "python"

      -- =============================
      -- Rust / C / C++
      -- =============================
      dap.adapters.codelldb = {
        type = "server",
        port = "${port}",
        executable = {
          command = vim.fn.stdpath "data" .. "/mason/bin/codelldb",
          args = { "--port", "${port}" },
        },
      }

      dap.configurations.rust = {
        {
          name = "Launch",
          type = "codelldb",
          request = "launch",
          program = function()
            return vim.fn.input("Path to executable: ", vim.fn.getcwd() .. "/target/debug/", "file")
          end,
          cwd = "${workspaceFolder}",
          stopOnEntry = false,
        },
      }

      dap.configurations.c = dap.configurations.rust
      dap.configurations.cpp = dap.configurations.rust

      -- =============================
      -- Go
      -- =============================
      dap.adapters.delve = {
        type = "server",
        port = "${port}",
        executable = {
          command = "dlv",
          args = { "dap", "-l", "127.0.0.1:${port}" },
        },
      }

      dap.configurations.go = {
        {
          type = "delve",
          name = "Debug",
          request = "launch",
          program = "${file}",
        },
        {
          type = "delve",
          name = "Debug test",
          request = "launch",
          mode = "test",
          program = "${file}",
        },
      }

      -- =============================
      -- Ruby (AUTO Rails vs Script)
      -- =============================
      dap.adapters.ruby = {
        type = "server",
        host = "127.0.0.1",
        port = "${port}",
        executable = {
          command = "rdbg",
          args = {
            "--open",
            "--port",
            "${port}",
            "-c",
            "--",
          },
        },
      }

      local function is_rails()
        local cwd = vim.fn.getcwd()
        return vim.fn.filereadable(cwd .. "/bin/rails") == 1
          or vim.fn.filereadable(cwd .. "/config/application.rb") == 1
      end

      dap.configurations.ruby = {
        -- 🔹 Auto: Rails oder Script
        {
          name = "Ruby: Auto (Rails / Script)",
          type = "ruby",
          request = "launch",
          program = function()
            if is_rails() then
              return "bin/rails"
            end
            return vim.fn.expand "%:p"
          end,
          args = function()
            if is_rails() then
              return { "server" }
            end
            return {}
          end,
          cwd = "${workspaceFolder}",
        },

        -- 🔹 Einzelnes Ruby-Script
        {
          name = "Ruby: Current file",
          type = "ruby",
          request = "launch",
          program = "${file}",
          cwd = "${workspaceFolder}",
        },

        -- 🔹 Rails Console (super nützlich)
        {
          name = "Rails: Console",
          type = "ruby",
          request = "launch",
          program = "bin/rails",
          args = { "console" },
          cwd = "${workspaceFolder}",
        },
      }

      -- =============================
      -- JavaScript / TypeScript
      -- =============================
      dap.adapters["pwa-node"] = {
        type = "server",
        host = "localhost",
        port = "${port}",
        executable = {
          command = "node",
          args = {
            vim.fn.stdpath "data" .. "/mason/packages/js-debug-adapter/js-debug/src/dapDebugServer.js",
            "${port}",
          },
        },
      }

      dap.configurations.javascript = {
        {
          type = "pwa-node",
          request = "launch",
          name = "Launch file",
          program = "${file}",
          cwd = "${workspaceFolder}",
        },
      }

      dap.configurations.typescript = dap.configurations.javascript
    end,
  },
}
