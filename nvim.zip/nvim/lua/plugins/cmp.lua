return {
  {
    "FelipeLema/cmp-async-path",
    -- Verwende GitHub Mirror statt Codeberg
    url = "https://github.com/FelipeLema/cmp-async-path.git",
  },
}
